package math32

import "math"

func Y1(x float32) float32 {
	return float32(math.Y1(float64(x)))
}
